import { CosmeticItem, Rarity } from '../types/game';

export const RARITY_LABELS: Record<Rarity, { label: string; textClass: string; borderClass: string }> = {
  common: { label: 'Yaygın', textClass: 'text-slate-300', borderClass: 'border-slate-600' },
  rare: { label: 'Nadir', textClass: 'text-sky-300', borderClass: 'border-sky-500/60' },
  epic: { label: 'Destansı', textClass: 'text-purple-300', borderClass: 'border-purple-500/60' },
  legendary: { label: 'Efsanevi', textClass: 'text-amber-300', borderClass: 'border-amber-400/70' },
  mythic: { label: 'Mitik', textClass: 'text-rose-300', borderClass: 'border-rose-400/80' },
};

// 127 Unique Cosmetics across Hats, Glasses, Skins, Trails, and 14 Secret Overlay Suits (???)
export const COSMETIC_CATALOG: CosmeticItem[] = [
  // ================= HATS (28) =================
  { id: 'hat_none', category: 'hat', name: 'Şapkasız', rarity: 'common', cost: 0, previewColor: '#64748B', shape: 'none' },
  { id: 'hat_aviator', category: 'hat', name: 'Pilot Kaskı', rarity: 'common', cost: 5, previewColor: '#92400E', shape: 'aviator', accentColor: '#38BDF8' },
  { id: 'hat_aviator_gold', category: 'hat', name: 'Altın Pilot Kaskı', rarity: 'epic', cost: 18, previewColor: '#D97706', shape: 'aviator', accentColor: '#FDE047' },
  { id: 'hat_aviator_red', category: 'hat', name: 'Kızıl Baron Kaskı', rarity: 'rare', cost: 12, previewColor: '#991B1B', shape: 'aviator', accentColor: '#FCA5A5' },
  { id: 'hat_party', category: 'hat', name: 'Parti Külahı', rarity: 'common', cost: 5, previewColor: '#EC4899', shape: 'party', accentColor: '#FACC15' },
  { id: 'hat_party_mint', category: 'hat', name: 'Nane Parti Külahı', rarity: 'common', cost: 6, previewColor: '#10B981', shape: 'party', accentColor: '#FDE047' },
  { id: 'hat_party_royal', category: 'hat', name: 'Mor Parti Külahı', rarity: 'rare', cost: 10, previewColor: '#7C3AED', shape: 'party', accentColor: '#F472B6' },
  { id: 'hat_propeller', category: 'hat', name: 'Pervaneli Şapka', rarity: 'rare', cost: 10, previewColor: '#3B82F6', shape: 'propeller', accentColor: '#EF4444' },
  { id: 'hat_propeller_neon', category: 'hat', name: 'Neon Pervane', rarity: 'epic', cost: 16, previewColor: '#06B6D4', shape: 'propeller', accentColor: '#EC4899' },
  { id: 'hat_propeller_gold', category: 'hat', name: 'Altın Pervane', rarity: 'legendary', cost: 28, previewColor: '#F59E0B', shape: 'propeller', accentColor: '#FEF08A' },
  { id: 'hat_crown', category: 'hat', name: 'Kral Tacı', rarity: 'epic', cost: 18, previewColor: '#FACC15', shape: 'crown', accentColor: '#EF4444' },
  { id: 'hat_crown_ice', category: 'hat', name: 'Buz Kraliçesi Tacı', rarity: 'epic', cost: 22, previewColor: '#38BDF8', shape: 'crown', accentColor: '#E0F2FE' },
  { id: 'hat_crown_crimson', category: 'hat', name: 'Yakut İmparator Tacı', rarity: 'legendary', cost: 30, previewColor: '#DC2626', shape: 'crown', accentColor: '#FDE047' },
  { id: 'hat_crown_obsidian', category: 'hat', name: 'Gölge Tacı', rarity: 'legendary', cost: 35, previewColor: '#1E293B', shape: 'crown', accentColor: '#A855F7' },
  { id: 'hat_wizard', category: 'hat', name: 'Büyücü Şapkası', rarity: 'rare', cost: 12, previewColor: '#4338CA', shape: 'wizard', accentColor: '#FDE047' },
  { id: 'hat_wizard_fire', category: 'hat', name: 'Alev Büyücüsü', rarity: 'epic', cost: 18, previewColor: '#B91C1C', shape: 'wizard', accentColor: '#FB923C' },
  { id: 'hat_wizard_emerald', category: 'hat', name: 'Orman Büyücüsü', rarity: 'rare', cost: 14, previewColor: '#15803D', shape: 'wizard', accentColor: '#86EFAC' },
  { id: 'hat_tophat', category: 'hat', name: 'Silindir Şapka', rarity: 'rare', cost: 11, previewColor: '#1E293B', shape: 'tophat', accentColor: '#EF4444' },
  { id: 'hat_tophat_royal', category: 'hat', name: 'Asil Mor Silindir', rarity: 'epic', cost: 17, previewColor: '#581C87', shape: 'tophat', accentColor: '#FACC15' },
  { id: 'hat_tophat_white', category: 'hat', name: 'Beyaz Sihirbaz', rarity: 'epic', cost: 19, previewColor: '#F8FAFC', shape: 'tophat', accentColor: '#38BDF8' },
  { id: 'hat_viking', category: 'hat', name: 'Viking Miğferi', rarity: 'rare', cost: 13, previewColor: '#64748B', shape: 'viking', accentColor: '#FEF3C7' },
  { id: 'hat_viking_gold', category: 'hat', name: 'Altın Viking Miğferi', rarity: 'legendary', cost: 26, previewColor: '#D97706', shape: 'viking', accentColor: '#FFFFFF' },
  { id: 'hat_chef', category: 'hat', name: 'Usta Aşçı Şapkası', rarity: 'common', cost: 7, previewColor: '#FFFFFF', shape: 'chef', accentColor: '#CBD5E1' },
  { id: 'hat_halo', category: 'hat', name: 'Melek Halesi', rarity: 'legendary', cost: 32, previewColor: '#FDE047', shape: 'halo', accentColor: '#FEF9C3' },
  { id: 'hat_devil', category: 'hat', name: 'Yaramaz Boynuzlar', rarity: 'epic', cost: 16, previewColor: '#DC2626', shape: 'devil', accentColor: '#7F1D1D' },
  { id: 'hat_beanie_red', category: 'hat', name: 'Kırmızı Bere', rarity: 'common', cost: 4, previewColor: '#EF4444', shape: 'beanie', accentColor: '#FFFFFF' },
  { id: 'hat_beanie_mint', category: 'hat', name: 'Turkuaz Bere', rarity: 'common', cost: 4, previewColor: '#14B8A6', shape: 'beanie', accentColor: '#FDE047' },
  { id: 'hat_astronaut', category: 'hat', name: 'Astronot Kaskı', rarity: 'legendary', cost: 36, previewColor: '#E2E8F0', shape: 'astronaut', accentColor: '#38BDF8' },
  { id: 'hat_crown_mythic', category: 'hat', name: 'Kozmik İmparator Tacı', rarity: 'mythic', cost: 150, previewColor: '#F43F5E', shape: 'crown', accentColor: '#38BDF8' },
  { id: 'hat_astronaut_mythic', category: 'hat', name: 'Galaktik Yıldız Kaskı', rarity: 'mythic', cost: 165, previewColor: '#312E81', shape: 'astronaut', accentColor: '#F43F5E' },
  { id: 'hat_halo_mythic', category: 'hat', name: 'Mitik Işık Halesi', rarity: 'mythic', cost: 180, previewColor: '#FB7185', shape: 'halo', accentColor: '#38BDF8' },
  { id: 'hat_samurai_kabuto', category: 'hat', name: 'Samuray Kabutosu', rarity: 'epic', cost: 24, previewColor: '#1E293B', shape: 'kabuto', accentColor: '#FACC15', isNew: true },
  { id: 'hat_witch_cat', category: 'hat', name: 'Cadı Kedi Şapkası', rarity: 'rare', cost: 15, previewColor: '#4C1D95', shape: 'witch_cat', accentColor: '#F472B6', isNew: true },
  { id: 'hat_ufo_abduct', category: 'hat', name: 'Mini UFO Anteni', rarity: 'legendary', cost: 42, previewColor: '#38BDF8', shape: 'ufo', accentColor: '#4ADE80', isNew: true },
  { id: 'hat_phoenix_plume', category: 'hat', name: 'Mitik Anka Sorgucu', rarity: 'mythic', cost: 175, previewColor: '#F43F5E', shape: 'phoenix_plume', accentColor: '#FDE047', isNew: true },

  // ================= GLASSES (22) =================
  { id: 'glasses_none', category: 'glasses', name: 'Gözlüksüz', rarity: 'common', cost: 0, previewColor: '#64748B', shape: 'none' },
  { id: 'glasses_sunglasses', category: 'glasses', name: 'Cool Güneş Gözlüğü', rarity: 'common', cost: 6, previewColor: '#0F172A', shape: 'sunglasses', accentColor: '#FFFFFF' },
  { id: 'glasses_sunglasses_red', category: 'glasses', name: 'Kızıl Cam Gözlük', rarity: 'rare', cost: 9, previewColor: '#991B1B', shape: 'sunglasses', accentColor: '#FCA5A5' },
  { id: 'glasses_sunglasses_gold', category: 'glasses', name: 'Altın Çerçeve', rarity: 'epic', cost: 15, previewColor: '#CA8A04', shape: 'sunglasses', accentColor: '#FEF08A' },
  { id: 'glasses_sunglasses_neon', category: 'glasses', name: 'Neon Yeşil Gözlük', rarity: 'rare', cost: 11, previewColor: '#16A34A', shape: 'sunglasses', accentColor: '#86EFAC' },
  { id: 'glasses_monocle', category: 'glasses', name: 'Altın Monokl', rarity: 'rare', cost: 12, previewColor: '#FBBF24', shape: 'monocle', accentColor: '#BAE6FD' },
  { id: 'glasses_monocle_ruby', category: 'glasses', name: 'Yakut Monokl', rarity: 'epic', cost: 17, previewColor: '#EF4444', shape: 'monocle', accentColor: '#FCA5A5' },
  { id: 'glasses_monocle_cyber', category: 'glasses', name: 'Siber Monokl', rarity: 'epic', cost: 18, previewColor: '#06B6D4', shape: 'monocle', accentColor: '#67E8F9' },
  { id: 'glasses_visor_cyber', category: 'glasses', name: 'Lazer Vizör', rarity: 'epic', cost: 16, previewColor: '#22D3EE', shape: 'visor', accentColor: '#0891B2' },
  { id: 'glasses_visor_red', category: 'glasses', name: 'Cyborg Kırmızı Vizör', rarity: 'legendary', cost: 25, previewColor: '#F43F5E', shape: 'visor', accentColor: '#FB7185' },
  { id: 'glasses_visor_gold', category: 'glasses', name: 'Altın Komutan Vizörü', rarity: 'legendary', cost: 28, previewColor: '#FACC15', shape: 'visor', accentColor: '#FEF08A' },
  { id: 'glasses_round_black', category: 'glasses', name: 'Retro Yuvarlak', rarity: 'common', cost: 5, previewColor: '#334155', shape: 'round', accentColor: '#E2E8F0' },
  { id: 'glasses_round_pink', category: 'glasses', name: 'Pembe Retro', rarity: 'common', cost: 6, previewColor: '#EC4899', shape: 'round', accentColor: '#FBCFE8' },
  { id: 'glasses_round_aqua', category: 'glasses', name: 'Okyanus Yuvarlak', rarity: 'rare', cost: 9, previewColor: '#0EA5E9', shape: 'round', accentColor: '#BAE6FD' },
  { id: 'glasses_star_gold', category: 'glasses', name: 'Yıldız Gözlük', rarity: 'epic', cost: 15, previewColor: '#FACC15', shape: 'star', accentColor: '#FEF08A' },
  { id: 'glasses_star_pink', category: 'glasses', name: 'Popstar Yıldız', rarity: 'epic', cost: 15, previewColor: '#F472B6', shape: 'star', accentColor: '#FFFFFF' },
  { id: 'glasses_heart_red', category: 'glasses', name: 'Kalp Gözlük', rarity: 'rare', cost: 11, previewColor: '#E11D48', shape: 'heart', accentColor: '#FDA4AF' },
  { id: 'glasses_heart_violet', category: 'glasses', name: 'Mor Kalp Gözlük', rarity: 'rare', cost: 12, previewColor: '#9333EA', shape: 'heart', accentColor: '#E9D5FF' },
  { id: 'glasses_pixel', category: 'glasses', name: '8-Bit Piksel Gözlük', rarity: 'legendary', cost: 26, previewColor: '#020617', shape: 'pixel', accentColor: '#FFFFFF' },
  { id: 'glasses_3d', category: 'glasses', name: '3D Sinema Gözlüğü', rarity: 'rare', cost: 10, previewColor: '#FFFFFF', shape: '3d', accentColor: '#3B82F6' },
  { id: 'glasses_eyepatch', category: 'glasses', name: 'Korsan Göz Bandı', rarity: 'common', cost: 6, previewColor: '#1E293B', shape: 'eyepatch', accentColor: '#0F172A' },
  { id: 'glasses_eyepatch_gold', category: 'glasses', name: 'Kaptan Göz Bandı', rarity: 'epic', cost: 16, previewColor: '#B45309', shape: 'eyepatch', accentColor: '#FACC15' },
  { id: 'glasses_visor_mythic', category: 'glasses', name: 'Mitik Süpernova Vizörü', rarity: 'mythic', cost: 140, previewColor: '#EC4899', shape: 'visor', accentColor: '#FDE047' },
  { id: 'glasses_star_mythic', category: 'glasses', name: 'Kızıl Yıldız Gözlük', rarity: 'mythic', cost: 145, previewColor: '#F43F5E', shape: 'star', accentColor: '#FDE047' },
  { id: 'glasses_phantom_mythic', category: 'glasses', name: 'Mitik Fırtına Gözlüğü', rarity: 'mythic', cost: 165, previewColor: '#0F172A', shape: 'phantom', accentColor: '#38BDF8' },
  { id: 'glasses_steampunk', category: 'glasses', name: 'Buhar Çarkı Gözlüğü', rarity: 'rare', cost: 14, previewColor: '#B45309', shape: 'steampunk', accentColor: '#38BDF8', isNew: true },
  { id: 'glasses_scouter', category: 'glasses', name: 'Güç Ölçer Vizör', rarity: 'epic', cost: 22, previewColor: '#22C55E', shape: 'scouter', accentColor: '#86EFAC', isNew: true },
  { id: 'glasses_hypno', category: 'glasses', name: 'Hipnoz Sarmalı', rarity: 'epic', cost: 24, previewColor: '#A855F7', shape: 'hypno', accentColor: '#FDE047', isNew: true },
  { id: 'glasses_eclipse', category: 'glasses', name: 'Mitik Güneş Tutulması', rarity: 'mythic', cost: 160, previewColor: '#0F172A', shape: 'eclipse', accentColor: '#F97316', isNew: true },
  { id: 'glasses_golden_rings', category: 'glasses', name: 'Sonsuz Altın Halka Vizörü', rarity: 'mythic', cost: 240, previewColor: '#FACC15', shape: 'golden_rings', accentColor: '#FEF08A', isNew: true, isSpecial: true },

  // ================= SKINS (39) =================
  { id: 'skin_classic', category: 'skin', name: 'Savan Grisi', rarity: 'common', cost: 0, previewColor: '#94A3B8', shape: 'solid' },
  { id: 'skin_pitch_black', category: 'skin', name: 'Zifiri Siyah', rarity: 'epic', cost: 25, previewColor: '#000000', shape: 'pitch_black', accentColor: '#09090B', isNew: true },
  { id: 'skin_pink', category: 'skin', name: 'Pamuk Şeker', rarity: 'common', cost: 5, previewColor: '#F472B6', shape: 'solid' },
  { id: 'skin_sky', category: 'skin', name: 'Gökyüzü Mavisi', rarity: 'common', cost: 5, previewColor: '#38BDF8', shape: 'solid' },
  { id: 'skin_mint', category: 'skin', name: 'Nane Yeşili', rarity: 'common', cost: 5, previewColor: '#34D399', shape: 'solid' },
  { id: 'skin_lavender', category: 'skin', name: 'Lavanta', rarity: 'common', cost: 6, previewColor: '#A78BFA', shape: 'solid' },
  { id: 'skin_peach', category: 'skin', name: 'Şeftali', rarity: 'common', cost: 6, previewColor: '#FB923C', shape: 'solid' },
  { id: 'skin_lemon', category: 'skin', name: 'Limonata', rarity: 'common', cost: 6, previewColor: '#FDE047', shape: 'solid' },
  { id: 'skin_ivory', category: 'skin', name: 'Kutupsal Beyaz', rarity: 'common', cost: 7, previewColor: '#F1F5F9', shape: 'solid' },
  { id: 'skin_sand', category: 'skin', name: 'Çöl Kumu', rarity: 'common', cost: 6, previewColor: '#D6D3D1', shape: 'solid' },
  { id: 'skin_coral', category: 'skin', name: 'Mercan', rarity: 'rare', cost: 9, previewColor: '#FB7185', shape: 'solid' },
  { id: 'skin_matcha', category: 'skin', name: 'Matcha Çayı', rarity: 'rare', cost: 9, previewColor: '#84CC16', shape: 'solid' },
  { id: 'skin_cobalt', category: 'skin', name: 'Kobalt Mavisi', rarity: 'rare', cost: 10, previewColor: '#2563EB', shape: 'solid' },
  { id: 'skin_crimson', category: 'skin', name: 'Kızıl Yakut', rarity: 'rare', cost: 11, previewColor: '#DC2626', shape: 'solid' },
  { id: 'skin_emerald', category: 'skin', name: 'Zümrüt Orman', rarity: 'rare', cost: 11, previewColor: '#059669', shape: 'solid' },
  { id: 'skin_plum', category: 'skin', name: 'Asil Erik', rarity: 'rare', cost: 11, previewColor: '#7E22CE', shape: 'solid' },
  { id: 'skin_espresso', category: 'skin', name: 'Kavrulmuş Kahve', rarity: 'rare', cost: 10, previewColor: '#78350F', shape: 'solid' },
  { id: 'skin_midnight', category: 'skin', name: 'Gece Kozmosu', rarity: 'epic', cost: 14, previewColor: '#4F46E5', shape: 'solid' },
  { id: 'skin_obsidian', category: 'skin', name: 'Obsidyen Gölge', rarity: 'epic', cost: 16, previewColor: '#1E293B', shape: 'solid' },
  { id: 'skin_bronze', category: 'skin', name: 'Antik Bronz', rarity: 'rare', cost: 12, previewColor: '#B45309', shape: 'metallic' },
  { id: 'skin_rosegold', category: 'skin', name: 'Roze Altın', rarity: 'epic', cost: 18, previewColor: '#F43F5E', shape: 'metallic' },
  { id: 'skin_platinum', category: 'skin', name: 'Platin Krom', rarity: 'epic', cost: 20, previewColor: '#E2E8F0', shape: 'metallic' },
  { id: 'skin_golden', category: 'skin', name: 'Saf Altın Fil', rarity: 'legendary', cost: 28, previewColor: '#FACC15', shape: 'metallic' },
  { id: 'skin_diamond', category: 'skin', name: 'Elmas Buz', rarity: 'legendary', cost: 32, previewColor: '#67E8F9', shape: 'metallic' },
  { id: 'skin_zebra', category: 'skin', name: 'Zebra Desenli', rarity: 'epic', cost: 17, previewColor: '#F8FAFC', shape: 'stripes', accentColor: '#0F172A' },
  { id: 'skin_tiger', category: 'skin', name: 'Kaplan Çizgili', rarity: 'epic', cost: 19, previewColor: '#F97316', shape: 'stripes', accentColor: '#1E293B' },
  { id: 'skin_dalmatian', category: 'skin', name: 'Benekli Dalmaçya', rarity: 'rare', cost: 13, previewColor: '#FFFFFF', shape: 'spots', accentColor: '#1E293B' },
  { id: 'skin_cow', category: 'skin', name: 'Savan İneği', rarity: 'rare', cost: 13, previewColor: '#FEF3C7', shape: 'spots', accentColor: '#78350F' },
  { id: 'skin_toxic', category: 'skin', name: 'Radyoaktif Lime', rarity: 'epic', cost: 18, previewColor: '#A3E635', shape: 'spots', accentColor: '#166534' },
  { id: 'skin_cyber', category: 'skin', name: 'Siber Neon', rarity: 'legendary', cost: 28, previewColor: '#06B6D4', shape: 'stripes', accentColor: '#EC4899' },
  { id: 'skin_lava', category: 'skin', name: 'Magma Lav', rarity: 'legendary', cost: 30, previewColor: '#7F1D1D', shape: 'spots', accentColor: '#FACC15' },
  { id: 'skin_galaxy', category: 'skin', name: 'Galaksi Yıldızlı', rarity: 'legendary', cost: 34, previewColor: '#312E81', shape: 'galaxy', accentColor: '#FDE047' },
  { id: 'skin_rainbow', category: 'skin', name: 'Gökkuşağı Bukalemun', rarity: 'legendary', cost: 40, previewColor: '#EC4899', shape: 'rainbow' },
  { id: 'skin_mythic_nebula', category: 'skin', name: 'Süpernova Nebulası', rarity: 'mythic', cost: 175, previewColor: '#701A75', shape: 'galaxy', accentColor: '#22D3EE' },
  { id: 'skin_mythic_inferno', category: 'skin', name: 'Kızıl Alev Kromu', rarity: 'mythic', cost: 185, previewColor: '#F43F5E', shape: 'metallic', accentColor: '#FDE047' },
  { id: 'skin_origami', category: 'skin', name: 'Origami Katlama', rarity: 'rare', cost: 16, previewColor: '#F8FAFC', shape: 'origami', accentColor: '#38BDF8', isNew: true },
  { id: 'skin_blueprint', category: 'skin', name: 'Mimar Çizimi', rarity: 'epic', cost: 24, previewColor: '#1D4ED8', shape: 'blueprint', accentColor: '#BAE6FD', isNew: true },
  { id: 'skin_stained_glass', category: 'skin', name: 'Vitray Mozaik', rarity: 'legendary', cost: 38, previewColor: '#1E1B4B', shape: 'mosaic', accentColor: '#F472B6', isNew: true },
  { id: 'skin_void_prism', category: 'skin', name: 'Mitik Hiçlik Prizması', rarity: 'mythic', cost: 195, previewColor: '#090D16', shape: 'void_prism', accentColor: '#22D3EE', isNew: true },

  // ================= ??? SECRET OVERLAY SUITS (14) =================
  { id: 'suit_police', category: 'suit', name: 'Komiser Üniforması', rarity: 'epic', cost: 0, dropOnly: true, dropRateChance: 1 / 5000, hiddenUntilUnlocked: true, dropRateLabel: "5.000'de 1 - Kıyafet Kasası", previewColor: '#1E3A8A', shape: 'police', accentColor: '#FACC15' },
  { id: 'suit_pirate', category: 'suit', name: 'Korsan Kaptan Paltosu', rarity: 'epic', cost: 0, dropOnly: true, dropRateChance: 1 / 6500, hiddenUntilUnlocked: true, dropRateLabel: "6.500'de 1 - Kıyafet Kasası", previewColor: '#991B1B', shape: 'pirate', accentColor: '#FBBF24' },
  { id: 'suit_doctor', category: 'suit', name: 'Başhekim Önlüğü', rarity: 'epic', cost: 0, dropOnly: true, dropRateChance: 1 / 8000, hiddenUntilUnlocked: true, dropRateLabel: "8.000'de 1 - Kıyafet Kasası", previewColor: '#F8FAFC', shape: 'doctor', accentColor: '#EF4444' },
  { id: 'suit_chef', category: 'suit', name: 'Usta Şef Ceketi', rarity: 'epic', cost: 0, dropOnly: true, dropRateChance: 1 / 10000, hiddenUntilUnlocked: true, dropRateLabel: "10.000'de 1 - Kıyafet Kasası", previewColor: '#FFFFFF', shape: 'chef_suit', accentColor: '#DC2626' },
  { id: 'suit_astronaut', category: 'suit', name: 'Uzay Kıyafeti', rarity: 'legendary', cost: 0, dropOnly: true, dropRateChance: 1 / 12500, hiddenUntilUnlocked: true, dropRateLabel: "12.500'de 1 - Kıyafet Kasası", previewColor: '#E2E8F0', shape: 'astronaut_suit', accentColor: '#F97316' },
  { id: 'suit_ninja', category: 'suit', name: 'Gölge Ninja Zırhı', rarity: 'legendary', cost: 0, dropOnly: true, dropRateChance: 1 / 15000, hiddenUntilUnlocked: true, dropRateLabel: "15.000'de 1 - Kıyafet Kasası", previewColor: '#0F172A', shape: 'ninja', accentColor: '#EF4444' },
  { id: 'suit_knight', category: 'suit', name: 'Gümüş Şövalye Zırhı', rarity: 'legendary', cost: 0, dropOnly: true, dropRateChance: 1 / 20000, hiddenUntilUnlocked: true, dropRateLabel: "20.000'de 1 - Kıyafet Kasası", previewColor: '#94A3B8', shape: 'knight', accentColor: '#FACC15' },
  { id: 'suit_superhero', category: 'suit', name: 'Süper Fil Kostümü', rarity: 'legendary', cost: 0, dropOnly: true, dropRateChance: 1 / 25000, hiddenUntilUnlocked: true, dropRateLabel: "25.000'de 1 - Kıyafet Kasası", previewColor: '#2563EB', shape: 'superhero', accentColor: '#EF4444' },
  { id: 'suit_samurai', category: 'suit', name: 'Kızıl Samuray Zırhı', rarity: 'legendary', cost: 0, dropOnly: true, dropRateChance: 1 / 35000, hiddenUntilUnlocked: true, dropRateLabel: "35.000'de 1 - Kıyafet Kasası", previewColor: '#7F1D1D', shape: 'samurai', accentColor: '#FDE047' },
  { id: 'suit_cyber', category: 'suit', name: 'Siberpunk Ceketi', rarity: 'mythic', cost: 0, dropOnly: true, dropRateChance: 1 / 45000, hiddenUntilUnlocked: true, dropRateLabel: "45.000'de 1 - Kıyafet Kasası", previewColor: '#111827', shape: 'cyber_suit', accentColor: '#22D3EE' },
  { id: 'suit_vampire', category: 'suit', name: 'Kont Drakula Pelerini', rarity: 'mythic', cost: 0, dropOnly: true, dropRateChance: 1 / 55000, hiddenUntilUnlocked: true, dropRateLabel: "55.000'de 1 - Kıyafet Kasası", previewColor: '#1E1B4B', shape: 'vampire', accentColor: '#DC2626' },
  { id: 'suit_pharaoh', category: 'suit', name: 'Altın Firavun Zırhı', rarity: 'mythic', cost: 0, dropOnly: true, dropRateChance: 1 / 70000, hiddenUntilUnlocked: true, dropRateLabel: "70.000'de 1 - Kıyafet Kasası", previewColor: '#F59E0B', shape: 'pharaoh', accentColor: '#0284C7' },
  { id: 'suit_king', category: 'suit', name: 'İmparator Pelerini', rarity: 'mythic', cost: 0, dropOnly: true, dropRateChance: 1 / 85000, hiddenUntilUnlocked: true, dropRateLabel: "85.000'de 1 - Kıyafet Kasası", previewColor: '#581C87', shape: 'king_robe', accentColor: '#FDE047' },
  { id: 'suit_tuxedo', category: 'suit', name: 'Kraliyet Smokin', rarity: 'mythic', cost: 0, dropOnly: true, dropRateChance: 1 / 100000, hiddenUntilUnlocked: true, dropRateLabel: "100.000'de 1 - Kutu", previewColor: '#0F172A', shape: 'tuxedo', accentColor: '#F8FAFC' },
  { id: 'suit_golden_rings', category: 'suit', name: 'Altın Halka İmparator Zırhı', rarity: 'mythic', cost: 340, previewColor: '#F59E0B', shape: 'golden_rings', accentColor: '#FEF08A', isNew: true, isSpecial: true },

  // ================= SEVİYELİ ÖZEL KOSTÜMLER (5) =================
  { id: 'suit_surypap', category: 'suit', name: 'Surypap', rarity: 'epic', cost: 0, dropOnly: true, leveledOnly: true, dropRateChance: 0.25, hiddenUntilUnlocked: true, dropRateLabel: 'Seviyeli Kıyafet Kasası (%25 Özel Havuz)', previewColor: '#F8FAFC', shape: 'surypap', accentColor: '#EF4444' },
  { id: 'suit_bass', category: 'suit', name: 'Bass', rarity: 'legendary', cost: 0, dropOnly: true, leveledOnly: true, dropRateChance: 0.22, hiddenUntilUnlocked: true, dropRateLabel: 'Seviyeli Kıyafet Kasası (%22 Özel Havuz)', previewColor: '#2563EB', shape: 'bass', accentColor: '#38BDF8' },
  { id: 'suit_swamp', category: 'suit', name: 'Swamp', rarity: 'legendary', cost: 0, dropOnly: true, leveledOnly: true, dropRateChance: 0.20, hiddenUntilUnlocked: true, dropRateLabel: 'Seviyeli Kıyafet Kasası (%20 Özel Havuz)', previewColor: '#1E293B', shape: 'swamp', accentColor: '#EC4899' },
  { id: 'suit_frind', category: 'suit', name: 'Frind', rarity: 'mythic', cost: 0, dropOnly: true, leveledOnly: true, dropRateChance: 0.17, hiddenUntilUnlocked: true, dropRateLabel: 'Seviyeli Kıyafet Kasası (%17 Özel Havuz)', previewColor: '#FACC15', shape: 'frind', accentColor: '#22C55E' },
  { id: 'suit_filyman', category: 'suit', name: 'Filyman', rarity: 'mythic', cost: 0, dropOnly: true, leveledOnly: true, dropRateChance: 0.16, hiddenUntilUnlocked: true, dropRateLabel: 'Seviyeli Kıyafet Kasası (%16 Özel Havuz)', previewColor: '#F59E0B', shape: 'filyman', accentColor: '#34D399' },

  // ================= TRAILS (23) =================
  { id: 'trail_none', category: 'trail', name: 'Klasik Hava Pufu', rarity: 'common', cost: 0, previewColor: '#E0F2FE', shape: 'puff' },
  { id: 'trail_cloud', category: 'trail', name: 'Pamuk Bulut', rarity: 'common', cost: 4, previewColor: '#FFFFFF', shape: 'puff' },
  { id: 'trail_bubbles', category: 'trail', name: 'Sabun Baloncukları', rarity: 'common', cost: 6, previewColor: '#7DD3FC', shape: 'ring' },
  { id: 'trail_water', category: 'trail', name: 'Su Damlaları', rarity: 'common', cost: 6, previewColor: '#38BDF8', shape: 'spark' },
  { id: 'trail_emerald', category: 'trail', name: 'Zümrüt Yaprak', rarity: 'common', cost: 7, previewColor: '#4ADE80', shape: 'spark' },
  { id: 'trail_smoke', category: 'trail', name: 'Gölge Dumanı', rarity: 'common', cost: 7, previewColor: '#475569', shape: 'puff' },
  { id: 'trail_sakura', category: 'trail', name: 'Kiraz Çiçeği', rarity: 'rare', cost: 10, previewColor: '#F9A8D4', shape: 'spark' },
  { id: 'trail_hearts', category: 'trail', name: 'Aşk Kalpleri', rarity: 'rare', cost: 11, previewColor: '#F43F5E', shape: 'spark' },
  { id: 'trail_sparkle', category: 'trail', name: 'Altın Kıvılcım', rarity: 'rare', cost: 12, previewColor: '#FACC15', shape: 'spark' },
  { id: 'trail_stars', category: 'trail', name: 'Yıldız Tozu', rarity: 'rare', cost: 12, previewColor: '#FDE047', shape: 'spark' },
  { id: 'trail_ice', category: 'trail', name: 'Buz Kristali', rarity: 'rare', cost: 11, previewColor: '#BAE6FD', shape: 'spark' },
  { id: 'trail_neon_cyan', category: 'trail', name: 'Siber Mavi İz', rarity: 'epic', cost: 15, previewColor: '#22D3EE', shape: 'spark' },
  { id: 'trail_neon_pink', category: 'trail', name: 'Neon Pembe İz', rarity: 'epic', cost: 15, previewColor: '#E879F9', shape: 'spark' },
  { id: 'trail_fire', category: 'trail', name: 'Alev Püskürtme', rarity: 'epic', cost: 16, previewColor: '#F97316', shape: 'spark' },
  { id: 'trail_lava', category: 'trail', name: 'Magma Damlaları', rarity: 'epic', cost: 17, previewColor: '#EF4444', shape: 'spark' },
  { id: 'trail_plasma', category: 'trail', name: 'Mor Plazma', rarity: 'epic', cost: 18, previewColor: '#A855F7', shape: 'ring' },
  { id: 'trail_lightning', category: 'trail', name: 'Şimşek Akımı', rarity: 'epic', cost: 19, previewColor: '#FDE047', shape: 'spark' },
  { id: 'trail_confetti', category: 'trail', name: 'Parti Konfetisi', rarity: 'epic', cost: 18, previewColor: '#EC4899', shape: 'confetti' },
  { id: 'trail_pixel', category: 'trail', name: 'Retro Piksel', rarity: 'rare', cost: 13, previewColor: '#34D399', shape: 'spark' },
  { id: 'trail_gold_coins', category: 'trail', name: 'Altın Yağmuru', rarity: 'legendary', cost: 26, previewColor: '#FACC15', shape: 'ring' },
  { id: 'trail_aurora', category: 'trail', name: 'Kuzey Işıkları', rarity: 'legendary', cost: 28, previewColor: '#2DD4BF', shape: 'aurora' },
  { id: 'trail_royal', category: 'trail', name: 'Kraliyet İzi', rarity: 'legendary', cost: 30, previewColor: '#9333EA', shape: 'royal' },
  { id: 'trail_rainbow', category: 'trail', name: 'Gökkuşağı İzi', rarity: 'legendary', cost: 34, previewColor: '#F472B6', shape: 'rainbow' },
  { id: 'trail_mythic_supernova', category: 'trail', name: 'Mitik Süpernova İzi', rarity: 'mythic', cost: 160, previewColor: '#FB7185', shape: 'rainbow' },
  { id: 'trail_music_notes', category: 'trail', name: 'Müzik Notaları', rarity: 'rare', cost: 15, previewColor: '#38BDF8', shape: 'music', accentColor: '#F472B6', isNew: true },
  { id: 'trail_binary', category: 'trail', name: 'Matris Kodları', rarity: 'epic', cost: 22, previewColor: '#22C55E', shape: 'binary', accentColor: '#86EFAC', isNew: true },
  { id: 'trail_butterflies', category: 'trail', name: 'Işıltılı Kelebekler', rarity: 'legendary', cost: 34, previewColor: '#F472B6', shape: 'butterflies', accentColor: '#FDE047', isNew: true },
  { id: 'trail_orbit_moons', category: 'trail', name: 'Mitik Yıldız Yörüngesi', rarity: 'mythic', cost: 170, previewColor: '#FDE047', shape: 'orbit_moons', accentColor: '#A855F7', isNew: true },
  { id: 'trail_golden_rings', category: 'trail', name: 'Kozmik Altın Halka İzi', rarity: 'mythic', cost: 220, previewColor: '#FACC15', shape: 'golden_rings', accentColor: '#FEF9C3', isNew: true, isSpecial: true },

  // ================= 5 ANIMATED PETS =================
  { id: 'pet_none', category: 'pet', name: 'Petsiz', rarity: 'common', cost: 0, previewColor: '#64748B', shape: 'none' },
  { id: 'pet_peanut_fairy', category: 'pet', name: 'Fıstık Perisi', rarity: 'rare', cost: 65, previewColor: '#FBBF24', shape: 'peanut_fairy', accentColor: '#FEF08A', isNew: true },
  { id: 'pet_pixel_soul', category: 'pet', name: 'Piksel Kalp', rarity: 'epic', cost: 140, previewColor: '#F43F5E', shape: 'pixel_soul', accentColor: '#38BDF8', isNew: true },
  { id: 'pet_cyber_drone', category: 'pet', name: 'Siber İHA', rarity: 'epic', cost: 175, previewColor: '#06B6D4', shape: 'cyber_drone', accentColor: '#EC4899', isNew: true },
  { id: 'pet_mini_dragon', category: 'pet', name: 'Mini Ejderha', rarity: 'legendary', cost: 280, previewColor: '#DC2626', shape: 'mini_dragon', accentColor: '#FACC15', isNew: true },
  { id: 'pet_celestial_phoenix', category: 'pet', name: 'Kozmik Anka', rarity: 'mythic', cost: 460, previewColor: '#F43F5E', shape: 'celestial_phoenix', accentColor: '#FDE047', isNew: true },
];

export const COSMETIC_BY_ID: Record<string, CosmeticItem> = Object.fromEntries(
  COSMETIC_CATALOG.map((item) => [item.id, item])
);

export const DEFAULT_COSMETIC_BY_CATEGORY: Record<CosmeticItem['category'], string> = {
  hat: 'hat_none',
  glasses: 'glasses_none',
  skin: 'skin_classic',
  trail: 'trail_none',
  suit: 'suit_none',
  pet: 'pet_none',
};

export function getCosmeticSellPrice(item: CosmeticItem): number {
  if (item.cost <= 0 || item.dropOnly) return 0;
  return Math.max(1, Math.floor(item.cost * 0.5));
}

export interface CosmeticOwnershipSummary {
  ownedCollectibles: number;
  totalCollectibles: number;
  byCategory: Record<CosmeticItem['category'] | 'leveled' | 'special', { owned: number; total: number }>;
}

export function getCosmeticOwnershipSummary(unlockedIds: string[]): CosmeticOwnershipSummary {
  const unlockedSet = new Set(unlockedIds);
  const byCategory: CosmeticOwnershipSummary['byCategory'] = {
    pet: { owned: 0, total: 0 },
    hat: { owned: 0, total: 0 },
    glasses: { owned: 0, total: 0 },
    skin: { owned: 0, total: 0 },
    trail: { owned: 0, total: 0 },
    suit: { owned: 0, total: 0 },
    leveled: { owned: 0, total: 0 },
    special: { owned: 0, total: 0 },
  };

  let ownedCollectibles = 0;
  let totalCollectibles = 0;

  for (const item of COSMETIC_CATALOG) {
    const isCollectible = item.cost > 0 || Boolean(item.dropOnly);
    if (!isCollectible) continue;
    totalCollectibles += 1;
    const isOwned = unlockedSet.has(item.id);
    if (isOwned) ownedCollectibles += 1;

    const bucketKey = item.leveledOnly ? 'leveled' : item.category;
    byCategory[bucketKey].total += 1;
    if (isOwned) byCategory[bucketKey].owned += 1;

    if (item.isSpecial) {
      byCategory.special.total += 1;
      if (isOwned) byCategory.special.owned += 1;
    }
  }

  return { ownedCollectibles, totalCollectibles, byCategory };
}


